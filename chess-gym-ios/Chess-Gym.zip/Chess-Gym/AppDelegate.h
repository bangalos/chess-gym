//
//  AppDelegate.h
//  Chess-Gym
//
//  Created by Garsh on 8/23/16.
//  Copyright (c) 2016 ChessGym. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
